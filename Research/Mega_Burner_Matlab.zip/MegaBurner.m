classdef MegaBurner < handle
    %MEGABURNER Host-side driver for the Arduino Mega "MegaBurner" EEPROM
    %programmer, ported from the Java desktop app (SerialHelper.java,
    %MegaBurner.java, Chips.java).
    %
    %   The Arduino firmware (MegaBurner.ino / MX29L3211.cpp) is NOT
    %   changed by this port - it still runs on the Mega 2560 exactly as
    %   written. This class only replicates the host <-> device serial
    %   protocol that the Java app used:
    %
    %       'C'                      -> check chip id
    %       'R<block>,<blockSize>'   -> read one block (raw bytes back)
    %       'E'                      -> erase whole chip (replies '%')
    %       'W<offset>,<page>,<n>'   -> write n bytes at offset
    %                                   (device replies '&' when ready to
    %                                   receive, then '%' when done)
    %
    %   Example:
    %       mb = MegaBurner();                  % default chip: MX29L3211
    %       MegaBurner.listPorts()               % see available ports
    %       mb.connect('COM5');                  % or '/dev/ttyACM0'
    %       id = mb.checkChip();                 % should read 'C2F9'
    %       mb.eraseChip();
    %       rom = loadRomFile('game.sfc');
    %       mb.writeChip(rom);
    %       verified = mb.verifyChip(rom);
    %       dump = mb.readChip();
    %       saveRomFile('dump.bin', dump);
    %       mb.disconnect();

    properties (SetAccess = private)
        Chip            % struct, see chipDefinitions.m
        Connected = false
        PortName = ''
    end

    properties
        Verbose = true  % set false to silence progress/log printing
    end

    properties (Access = private)
        SerialPort      % serialport object
    end

    properties (Constant, Access = private)
        BAUD_RATE      = 115200
        SIGNAL_BEGIN   = '&'   % device ready to receive write data
        SIGNAL_END     = '%'   % operation complete
        CHECK_COMMAND  = 'C'
        READ_COMMAND   = 'R'
        ERASE_COMMAND  = 'E'
        WRITE_COMMAND  = 'W'
        CONNECT_TIMEOUT = 10   % seconds, generic command/response timeout
        ERASE_TIMEOUT   = 30   % seconds, chip erase can take a while
        WRITE_TIMEOUT   = 10   % seconds, per page-program block
    end

    methods
        function obj = MegaBurner(chipName)
            %MEGABURNER Construct a driver for the given chip (default MX29L3211)
            if nargin < 1
                chipName = 'MX29L3211';
            end
            obj.Chip = chipDefinitions(chipName);
        end

        function connect(obj, portName)
            %CONNECT Open the serial port and wait for the Arduino to reset/boot.
            %   Equivalent to SerialHelper.connect().
            if obj.Connected
                obj.disconnect();
            end

            try
                obj.SerialPort = serialport(portName, obj.BAUD_RATE, ...
                    'Timeout', obj.CONNECT_TIMEOUT);
            catch ME
                error('MegaBurner:connect', 'Could not open port "%s": %s', ...
                    portName, ME.message);
            end

            configureTerminator(obj.SerialPort, "CR/LF");

            % The Mega resets when the serial port opens; give the
            % bootloader/firmware time to start, same as the 1000ms
            % Thread.sleep(1000) in SerialHelper.connect().
            pause(1.0);
            flush(obj.SerialPort);

            obj.Connected = true;
            obj.PortName = portName;
            obj.log('Serial port "%s" connected.', portName);
        end

        function disconnect(obj)
            %DISCONNECT Close the serial port.
            if obj.Connected
                clear obj.SerialPort;
                obj.SerialPort = [];
                obj.Connected = false;
                obj.log('Serial port "%s" disconnected.', obj.PortName);
            end
        end

        function id = checkChip(obj)
            %CHECKCHIP Send the check command and return the chip id string.
            %   Equivalent to SerialHelper.check(). The firmware answers
            %   with the id printed as ASCII hex characters (e.g. 'C2F9'
            %   for the MX29L3211), NOT raw bytes.
            obj.assertConnected();
            flush(obj.SerialPort, "input");

            write(obj.SerialPort, uint8(obj.CHECK_COMMAND), "uint8");

            raw = read(obj.SerialPort, 4, "uint8");
            id = char(raw(:)');

            if numel(id) < 4
                warning('MegaBurner:checkChip', ...
                    'Only received %d of 4 id bytes (timeout).', numel(id));
            end

            obj.log('Chip code is "%s".', id);
        end

        function matched = isChipMatched(obj)
            %ISCHIPMATCHED Convenience wrapper: checkChip() vs expected id.
            id = obj.checkChip();
            matched = strcmpi(id, obj.Chip.id);
            if matched
                obj.log('Chip in place: %s (%s).', obj.Chip.name, id);
            else
                obj.log('Chip mismatch: expected %s, got %s.', obj.Chip.id, id);
            end
        end

        function data = readChip(obj)
            %READCHIP Read the entire chip capacity, one block at a time.
            %   Equivalent to SerialHelper.read().
            obj.assertConnected();
            flush(obj.SerialPort, "input");

            c = obj.Chip;
            data = zeros(1, c.capacity, 'uint8');

            obj.log('READ operation started...');
            t0 = tic;

            for block = 0:(c.readBlockCount - 1)
                cmd = sprintf('%s%d,%d', obj.READ_COMMAND, block, c.readBlock);
                write(obj.SerialPort, uint8(cmd), "uint8");

                bytes = read(obj.SerialPort, c.readBlock, "uint8");
                if numel(bytes) < c.readBlock
                    error('MegaBurner:readChip', ...
                        'Connection reset. Read operation aborted (block %d).', block);
                end

                idx0 = block * c.readBlock + 1;
                data(idx0:idx0 + c.readBlock - 1) = bytes;

                obj.progress((block + 1) * c.readBlock, c.capacity);
            end

            obj.log('completed! (%.2f s)', toc(t0));
        end

        function ok = eraseChip(obj)
            %ERASECHIP Erase the whole chip.
            %   Equivalent to SerialHelper.erase(). Blocks until the
            %   device replies with SIGNAL_END ('%').
            obj.assertConnected();
            flush(obj.SerialPort, "input");

            obj.log('ERASE operation started...');
            t0 = tic;

            write(obj.SerialPort, uint8(obj.ERASE_COMMAND), "uint8");

            oldTimeout = obj.SerialPort.Timeout;
            obj.SerialPort.Timeout = obj.ERASE_TIMEOUT;
            obj.wait4Signal(obj.SIGNAL_END);
            obj.SerialPort.Timeout = oldTimeout;

            obj.log('completed! (%.2f s)', toc(t0));
            ok = true;
        end

        function comingData = verifyChip(obj, refData)
            %VERIFYCHIP Read blocks back and compare against refData.
            %   Equivalent to SerialHelper.verify(). Stops at the first
            %   block containing a mismatch (matches the Java behaviour).
            obj.assertConnected();
            flush(obj.SerialPort, "input");

            c = obj.Chip;
            refData = uint8(refData(:)');
            comingData = zeros(1, numel(refData), 'uint8');

            obj.log('VERIFY operation started...');
            t0 = tic;
            mismatches = 0;

            for block = 0:(c.readBlockCount - 1)
                beginIdx = block * c.readBlock;      % 0-based
                endIdx   = beginIdx + c.readBlock;    % 0-based, exclusive

                if numel(refData) < endIdx
                    readSize = numel(refData) - beginIdx;
                else
                    readSize = c.readBlock;
                end
                if readSize <= 0
                    continue
                end

                cmd = sprintf('%s%d,%d', obj.READ_COMMAND, block, readSize);
                write(obj.SerialPort, uint8(cmd), "uint8");

                bytes = read(obj.SerialPort, readSize, "uint8");
                comingData(beginIdx+1:beginIdx+readSize) = bytes;

                mismatchMask = bytes ~= refData(beginIdx+1:beginIdx+readSize);
                mismatches = mismatches + nnz(mismatchMask);

                if mismatches > 0
                    fromAddr = beginIdx;
                    toAddr = (block + 1) * c.readBlock - 1;
                    obj.log('Address %08X to %08X compared different, verify failed!', ...
                        fromAddr, toAddr);
                    break  % matches Java: stop at first mismatching block
                else
                    obj.progress((block + 1) * c.readBlock, numel(refData));
                end
            end

            if mismatches == 0
                obj.log('completed! (%.2f s)', toc(t0));
            end
        end

        function writeChip(obj, data)
            %WRITECHIP Write data to the chip starting at offset 0.
            %   Equivalent to SerialHelper.write().
            obj.assertConnected();
            flush(obj.SerialPort, "input");

            c = obj.Chip;
            data = uint8(data(:)');
            totalLength = numel(data);

            obj.log('WRITE operation started...');
            t0 = tic;

            oldTimeout = obj.SerialPort.Timeout;
            obj.SerialPort.Timeout = obj.WRITE_TIMEOUT;

            i = 0; % 0-based offset, matches Java loop
            while i < totalLength
                nextBlock = i + c.writeBlock;
                if nextBlock <= totalLength
                    writeCount = c.writeBlock;
                else
                    writeCount = totalLength - i;
                end

                cmd = sprintf('%s%d,%d,%d', obj.WRITE_COMMAND, i, c.pageSize, writeCount);
                write(obj.SerialPort, uint8(cmd), "uint8");

                obj.wait4Signal(obj.SIGNAL_BEGIN);

                chunk = data(i+1:i+writeCount);
                write(obj.SerialPort, chunk, "uint8");

                obj.wait4Signal(obj.SIGNAL_END);

                obj.progress(i, totalLength);
                i = i + writeCount;
            end

            obj.SerialPort.Timeout = oldTimeout;
            obj.log('completed. (%.2f s)', toc(t0));
        end
    end

    methods (Static)
        function ports = listPorts()
            %LISTPORTS List available serial ports.
            %   Equivalent to SerialHelper.getAvailableSerialPorts().
            ports = serialportlist("available");
        end
    end

    methods (Access = private)
        function assertConnected(obj)
            if ~obj.Connected
                error('MegaBurner:notConnected', ...
                    'Not connected. Call connect(portName) first.');
            end
        end

        function wait4Signal(obj, sigChar)
            %WAIT4SIGNAL Block byte-by-byte until sigChar is received.
            %   Equivalent to SerialHelper.wait4Signal(). Raw read() is
            %   used (not readline) because the signal can be followed
            %   immediately by binary data (the '&' write-ready signal).
            target = uint8(sigChar);
            deadline = tic;
            maxWait = obj.SerialPort.Timeout * 5; % generous overall ceiling

            while true
                b = read(obj.SerialPort, 1, "uint8");
                if ~isempty(b) && b(1) == target
                    return
                end
                if isempty(b) && toc(deadline) > maxWait
                    error('MegaBurner:timeout', ...
                        'Connection reset. Timed out waiting for signal "%s".', sigChar);
                end
            end
        end

        function log(obj, fmt, varargin)
            if obj.Verbose
                fprintf(['[MegaBurner] ' fmt '\n'], varargin{:});
            end
        end

        function progress(obj, done, total)
            if obj.Verbose
                fprintf('[MegaBurner] %d / %d bytes (%.1f%%)\n', ...
                    done, total, 100 * done / total);
            end
        end
    end
end
