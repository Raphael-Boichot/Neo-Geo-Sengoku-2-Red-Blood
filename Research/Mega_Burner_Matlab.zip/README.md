# MegaBurner - MATLAB host driver

This is a MATLAB port of the **host-side** logic of the Java MegaBurner
desktop app (SWT GUI + RXTX serial). It talks to the same **Arduino Mega
2560 firmware** (`MegaBurner.ino` / `MX29L3211.cpp`), which is **not**
changed — it directly manipulates AVR registers (`DDRF`, `PORTH`, ...)
and can only run as Arduino firmware, not MATLAB.

No GUI is included, per request — this is a set of functions/a class you
call from the MATLAB command line or your own scripts.

## Files

| File                  | Ports                                              |
|------------------------|----------------------------------------------------|
| `MegaBurner.m`          | `SerialHelper.java`, relevant parts of `MegaBurner.java` |
| `chipDefinitions.m`     | `Chips.java`, `chips/Chip.java`, `chips/MX29L3211.java` |
| `loadRomFile.m`         | `FileHelper.loadFile()`                             |
| `saveRomFile.m`         | `FileHelper.saveFile()`                             |
| `hexDump.m`             | `HexHelper.convertToHex()`                          |
| `example_usage.m`       | Sample workflow (open port -> check -> erase -> write -> verify -> read -> save) |

`Console.java`, `Widgets.java`, `SaveDialog.java`, `CommException.java`
and the Eclipse `SWTResourceManager.java` were GUI/plumbing-only and are
not needed — MATLAB errors/`warning()` replace `CommException`, and
`Verbose`/`fprintf` replace the `Console` log panel.

## Requirements

- MATLAB with the **Instrument Control Toolbox** family's `serialport`
  interface (MATLAB R2019b+; this is the modern replacement for the
  legacy `serial` object, so no extra "RXTX" driver install is needed
  the way the Java app required `rxtxSerial`).

## Quick start

```matlab
MegaBurner.listPorts()          % see available serial ports

mb = MegaBurner();               % chip defaults to MX29L3211
mb.connect('COM5');              % or e.g. '/dev/ttyACM0' on Linux/Mac

id = mb.checkChip();             % 'C2F9' for the MX29L3211
mb.eraseChip();

rom = loadRomFile('game.sfc');
mb.writeChip(rom);
mb.verifyChip(rom);

dump = mb.readChip();
saveRomFile('dump.bin', dump);

mb.disconnect();
```

## Protocol (unchanged, reverse-engineered from the .ino/.cpp)

| Host sends           | Meaning                                              | Device replies |
|-----------------------|-------------------------------------------------------|-----------------|
| `C`                   | Check chip ID                                          | 4 ASCII hex chars, e.g. `C2F9` |
| `R<block>,<size>`      | Read one block (16-bit mode, little-endian bytes)      | `<size>` raw bytes |
| `E`                   | Erase whole chip                                        | `%` when done (can take a while) |
| `W<offset>,<page>,<n>` | Write `n` bytes at `offset`, `page` bytes/page-program  | `&` when ready to receive, then `n` raw bytes are sent, then `%` when done |

Default block/page sizes (from `Chip.java` / `MX29L3211.java`):
readBlock = writeBlock = 4096 bytes, pageSize = 128 bytes,
capacity = 4,194,304 bytes (4 MiB).

## Things worth double-checking on real hardware

1. **Timeouts.** `ERASE_TIMEOUT` (30 s) and `WRITE_TIMEOUT` (10 s per
   write block) are conservative guesses based on typical flash timing.
   If you see `MegaBurner:timeout` errors during erase/write on your
   actual chip, just raise `MegaBurner.ERASE_TIMEOUT` /
   `MegaBurner.WRITE_TIMEOUT` (they're `Constant` properties — easiest
   is to edit the numbers at the top of `MegaBurner.m`) or add a
   `Timeout` argument if you'd like the class parameterized further.
2. **Port reset delay.** `connect()` pauses 1 s after opening the port
   for the Mega to reboot, same as the Java app. If your board/bootloader
   needs longer, increase the `pause(1.0)` in `MegaBurner.connect`.
3. **`checkChip()` byte count.** The firmware prints the 2 ID bytes with
   `Serial.print(byte, HEX)`, which drops the leading zero for values
   `< 0x10`. For the MX29L3211 (`C2`, `F9`) this never happens, but if
   you add a chip whose ID bytes have a leading zero nibble, you may get
   fewer than 4 characters back — this was a pre-existing quirk in the
   original Java/Arduino code, not introduced by this port.
