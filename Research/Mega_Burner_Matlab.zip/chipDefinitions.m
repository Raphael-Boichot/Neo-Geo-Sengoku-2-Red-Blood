function chip = chipDefinitions(name)
%CHIPDEFINITIONS EEPROM/flash chip definitions.
%   Ported from Chips.java / chips/Chip.java / chips/MX29L3211.java
%
%   CHIP = CHIPDEFINITIONS() returns the default chip (MX29L3211).
%   CHIP = CHIPDEFINITIONS(NAME) returns the chip whose .name matches NAME.
%
%   To add a new chip, add another struct to the "chips" array below
%   (this mirrors how a new class was added to the Java chips[] array).

if nargin < 1
    name = 'MX29L3211';
end

chips = struct( ...
    'name',        {'MX29L3211'}, ...
    'displayName', {'   MX29L2311 (C2F9)'}, ...
    'id',          {'C2F9'}, ...
    'type',        {'3.3v/32MBit/4MiB'}, ...
    'capacity',    {4194304}, ...   % bytes (4 MiB)
    'pageSize',    {128}, ...       % bytes per page-program cycle
    'readBlock',   {4096}, ...      % bytes per read block (Chip.java default)
    'writeBlock',  {4096} ...       % bytes per write block (Chip.java default)
);

idx = find(strcmpi({chips.name}, name), 1);
if isempty(idx)
    error('chipDefinitions:unknownChip', 'Unknown chip "%s".', name);
end

chip = chips(idx);

% Derived field, equivalent to Chip.getReadBlockCount()
chip.readBlockCount = chip.capacity / chip.readBlock;

end
