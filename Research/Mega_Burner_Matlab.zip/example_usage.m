%% MegaBurner - example usage
% This mirrors the workflow of the original Java desktop app, but as a
% plain script (no GUI). The Arduino firmware (MegaBurner.ino /
% MX29L3211.cpp) must already be flashed onto the Mega 2560, unchanged.

%% 1. Find and open the port
MegaBurner.listPorts()

mb = MegaBurner();          % defaults to the MX29L3211 chip definition
mb.connect('COM5');         % replace with your port, e.g. '/dev/ttyACM0'

%% 2. Check the chip is present and matches what we expect
id = mb.checkChip();                 % e.g. 'C2F9'
assert(mb.isChipMatched(), 'Chip id does not match the expected chip.');

%% 3. Erase
mb.eraseChip();

%% 4. Load a ROM image and write it
rom = loadRomFile('game.sfc');
mb.writeChip(rom);

%% 5. Verify what's on the chip against the file
verified = mb.verifyChip(rom);       % logs a mismatch message and stops
                                      % at the first bad block, matching
                                      % the Java app's behaviour

%% 6. Full read-back / dump to a file
dump = mb.readChip();
saveRomFile('dump.bin', dump);

%% 7. Optional: inspect the first 256 bytes as a hex dump
disp(hexDump(dump(1:256)));

%% 8. Disconnect
mb.disconnect();
