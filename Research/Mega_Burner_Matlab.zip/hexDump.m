function str = hexDump(data)
%HEXDUMP Classic 16-bytes-per-line hex + ASCII dump of a byte vector.
%   STR = HEXDUMP(DATA) mirrors HexHelper.convertToHex() from the Java
%   app: each line shows the starting offset, 16 space-separated hex
%   byte values, and the printable ASCII representation (non-printable
%   bytes shown as '.').
%
%   Example:
%       disp(hexDump(loadRomFile('game.sfc')))

data = uint8(data(:)');
n = numel(data);
lines = strings(0, 1);

for offset = 0:16:n-1
    chunk = data(offset+1 : min(offset+16, n));

    hexPart = sprintf('%02X ', chunk);
    if numel(hexPart) < 16*3
        hexPart = [hexPart, blanks(16*3 - numel(hexPart))]; % pad short last line
    end

    asciiPart = chunk;
    nonPrintable = asciiPart < 32 | asciiPart == 127;
    asciiPart(nonPrintable) = '.';

    line = sprintf('%08Xh: %s; %s', offset, hexPart, char(asciiPart));
    lines(end+1, 1) = line; %#ok<AGROW>
end

str = strjoin(lines, newline);

end
