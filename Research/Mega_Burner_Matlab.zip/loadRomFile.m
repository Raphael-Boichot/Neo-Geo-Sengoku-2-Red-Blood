function data = loadRomFile(filePath)
%LOADROMFILE Load a ROM/binary file as a row vector of uint8 bytes.
%   DATA = LOADROMFILE(FILEPATH) reads the whole file into memory.
%   Equivalent to FileHelper.loadFile() in the Java app (works for
%   .sfc, .nes, .bin, or any other raw binary file).

fid = fopen(filePath, 'rb');
if fid == -1
    error('loadRomFile:openFailed', 'Could not open file "%s".', filePath);
end

cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
data = fread(fid, Inf, 'uint8=>uint8')';

end
