function saveRomFile(filePath, data)
%SAVEROMFILE Write a row/column vector of uint8 bytes to a binary file.
%   SAVEROMFILE(FILEPATH, DATA) writes DATA as raw bytes.
%   Equivalent to FileHelper.saveFile() in the Java app.

fid = fopen(filePath, 'wb');
if fid == -1
    error('saveRomFile:openFailed', 'Could not open file "%s" for writing.', filePath);
end

cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
fwrite(fid, uint8(data), 'uint8');

end
